-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Ноя 19 2017 г., 23:25
-- Версия сервера: 10.1.25-MariaDB
-- Версия PHP: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `zoo`
--

-- --------------------------------------------------------

--
-- Структура таблицы `feeding`
--

CREATE TABLE `feeding` (
  `feeding_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `student_id` int(11) NOT NULL,
  `animal_id` int(11) NOT NULL,
  `food_id` int(11) NOT NULL,
  `quantity_food` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `feeding`
--

INSERT INTO `feeding` (`feeding_id`, `date`, `student_id`, `animal_id`, `food_id`, `quantity_food`) VALUES
(1, '2017-11-01', 1, 2, 1, 15),
(2, '2017-11-01', 1, 2, 1, 20),
(3, '2017-11-01', 1, 2, 1, 20),
(4, '2017-11-18', 1, 1, 3, 12),
(5, '2017-10-31', 1, 1, 3, 15),
(6, '2017-11-02', 1, 1, 3, 43),
(7, '2017-11-15', 2, 1, 3, 32),
(12, '2017-11-25', 1, 1, 3, 123),
(13, '2017-11-16', 1, 1, 1, 32);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `feeding`
--
ALTER TABLE `feeding`
  ADD PRIMARY KEY (`feeding_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `feeding`
--
ALTER TABLE `feeding`
  MODIFY `feeding_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
